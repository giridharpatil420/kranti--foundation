
import React, { useState } from "react";
import jsPDF from "jspdf";

export default function Home() {
  const [name, setName] = useState("");
  const [id, setId] = useState("");

  const generateID = () => {
    const newId = `KF2025BEL${Math.floor(1000 + Math.random() * 9000)}`;
    setId(newId);
    const doc = new jsPDF();
    doc.text("Kranti Foundation ID Card", 20, 20);
    doc.text(`Name: ${name}`, 20, 40);
    doc.text(`Member ID: ${newId}`, 20, 50);
    doc.save("Kranti_ID_Card.pdf");
  };

  return (
    <main style={{ padding: 40 }}>
      <h1>Kranti Foundation Belgaum</h1>
      <input
        type="text"
        placeholder="Your Name"
        value={name}
        onChange={(e) => setName(e.target.value)}
        style={{ marginRight: 10 }}
      />
      <button onClick={generateID}>Generate ID</button>
      {id && <p>Your ID: {id}</p>}
    </main>
  );
}
